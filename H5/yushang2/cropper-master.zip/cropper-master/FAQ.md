# FAQ


## Common

### How to crop an new area after zoom in or zoom out?

> Just double click your mouse to enter crop mode.


### How to move the image after crop an area?

> Just double click your mouse to enter move mode.


### How to fix aspect ratio in free ratio mode?

> Just hold the `shift` key when you resize the crop box.


### How to crop an square area in free ratio mode?

> Just hold the `shift` key when you crop on the image.
